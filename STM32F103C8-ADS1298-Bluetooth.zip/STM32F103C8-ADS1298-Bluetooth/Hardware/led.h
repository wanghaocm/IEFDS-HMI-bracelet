#ifndef __LED_H
#define __LED_H	 
#include "sys.h"



#define LED1 PBout(3)	
#define LED2 PBout(4)	

#define DS1 LED1
#define DS2 LED2

#define LED_1 LED1 	
#define LED_2 LED2


#define LED_ON 0
#define LED_OFF 1



void LED_Init(void);//��ʼ��

		 				    
#endif
